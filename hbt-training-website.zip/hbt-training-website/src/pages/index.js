import Image from 'next/image';
import { useState } from 'react';

export default function Home() {
  return (
    <div style={{ backgroundColor: '#000', color: '#fff', padding: '2rem', fontFamily: 'sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <Image src="/logo.png" alt="HBT Logo" width={120} height={50} />
      </header>

      <section style={{ textAlign: 'center' }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 'bold' }}>Stronger Every Day.</h1>
        <p style={{ maxWidth: '600px', margin: '1rem auto' }}>
          Build real strength with expert-led, no-fluff online coaching that actually works.
        </p>
        <button style={{ padding: '0.75rem 1.5rem', backgroundColor: '#fff', color: '#000', fontWeight: 'bold', borderRadius: '8px' }}>
          Get Started
        </button>
      </section>

      <section style={{ textAlign: 'center', marginTop: '3rem' }}>
        <Image src="/hero-photo.jpg" alt="Hero Image" width={800} height={400} />
      </section>

      <section style={{ maxWidth: '800px', margin: '3rem auto' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: 'bold', textAlign: 'center' }}>What is HBT Training?</h2>
        <p>
          HBT stands for Habit-Based Training — because long-term strength comes from daily consistency, not random workouts.
        </p>
        <ul>
          <li>✅ Structured programming</li>
          <li>✅ Habit coaching for lifestyle change</li>
          <li>✅ Regular check-ins + personal guidance</li>
        </ul>
      </section>

      <section style={{ textAlign: 'center', marginTop: '3rem' }}>
        <Image src="/transformation.jpg" alt="Client Transformation" width={600} height={300} />
        <p style={{ fontStyle: 'italic', marginTop: '0.5rem' }}>“I’ve never felt this strong in my life.” – HBT Client</p>
      </section>

      <section style={{ textAlign: 'center', marginTop: '3rem' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: 'bold' }}>Ready to get stronger?</h2>
        <p>Book a free call to see if we’re the right fit.</p>
        <div style={{ marginTop: '1rem' }}>
          <button style={{ padding: '0.75rem 1.5rem', backgroundColor: '#fff', color: '#000', fontWeight: 'bold', borderRadius: '8px', marginRight: '1rem' }}>
            Book a Call
          </button>
          <button style={{ padding: '0.75rem 1.5rem', border: '1px solid #fff', color: '#fff', borderRadius: '8px' }}>
            DM us on Instagram
          </button>
        </div>
      </section>
    </div>
  );
}
